function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5lb4wBCd4rA":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

